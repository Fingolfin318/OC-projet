FlashCareer
Auteurs : Guillaume Kaufmann, Ireneo Pistorius, Michael Bruchez

Description du projet :

OBJECTIF DU PROJET :
Ce site est un site d'offre d'emploi sur lequelle on peut s'inscrire en tant que chercheur d'emploi/étudiant ou en tant qu'employeur.
Si on cherche un emploi, il faudra remplir un CV qui sera retenu en envoyer quand il va postuler à une offre.
Si on est employeur, on a la possibilité de poster une offre d'emploie qui sera mise en ligne sur laquelle un chercheur d'emploi/étudiant peut postuler.

DIFFERENTE PAGES DU PROJET :
La première page web est la page d'accueil qui comporte une description briève et humoristique du site, avec différents boutons qui renvoient aux différentes pages du site : Profil, Postuler à une offre, Poster une offre, A propos du site, Se connecter.
Il y a une page de connection où il faut entrer son identifiant et son mot de passe du site.
Cette page renvoie à deux pages différentes selon le profil de l'utilisateur : soit en tant que chercheur d'emploi/étudiant ou soit en tant que patron.
    Pour les chercheurs d'emploi : sur cette page il faut remplir son CV sous forme de formulaire.
    Pour les patrons : sur cette page il y a un formulaire pour enregistrer son entreprise.
Il y a évidemment la page qui affiche les offres d'emploi ou l'utilisateur peut postuler.
Mais sans oublier aussi la page qui permet au patron de poster une offre qui l'intéresse.
Sans oublier la page qui affiche le profil de l'utilisateur si il est étudiant ou patron avec son nom, prénom, ...
Et finalement il y a la page "à propos du site" qui affiche différente information sur le site et ses créateurs.

